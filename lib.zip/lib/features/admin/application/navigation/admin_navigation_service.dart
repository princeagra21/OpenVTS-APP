class AdminNavigationService {
  const AdminNavigationService();
}
