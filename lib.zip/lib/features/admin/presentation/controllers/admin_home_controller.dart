class AdminHomeController {
  const AdminHomeController();
}
