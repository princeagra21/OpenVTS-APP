import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:open_vts/core/utils/app_cancellation.dart';
import 'package:open_vts/core/config/app_config.dart';
import 'package:open_vts/core/utils/adaptive_utils.dart';
import 'package:open_vts/core/utils/app_utils.dart';
import 'package:open_vts/features/admin/di/admin_providers.dart';
import 'package:open_vts/core/providers/core_providers.dart';
import 'package:open_vts/core/providers/repository_providers.dart';
import 'package:open_vts/core/providers/legacy_repository_adapter_providers.dart';
import 'package:open_vts/features/shell/presentation/providers/app_bar_notification_provider.dart';
import 'package:open_vts/features/admin/presentation/layout/app_layout.dart';
import 'package:open_vts/shared/models/admin_profile.dart';
import 'package:open_vts/shared/widgets/app_shimmer.dart';
import 'package:open_vts/shared/widgets/open_vts/open_vts_components.dart';
import 'package:open_vts/shared/widgets/top_bar.dart';
import 'package:open_vts/core/error/legacy_error_presenter.dart';
import 'package:open_vts/core/utils/app_logo.dart';
import 'package:material_symbols_icons/material_symbols_icons.dart';
import 'package:open_vts/core/theme/app_fonts.dart';
import 'package:open_vts/core/router/route_names.dart';
import 'package:open_vts/core/theme/open_vts_theme.dart';

import 'package:open_vts/core/state/update_local_ui_state.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  Timer? _badgeRefreshTimer;
  AdminProfile? _profile;
  bool _loadingProfile = false;
  AppCancellationHandle? _profileToken;
  String _accessToken = '';
  String _baseUrl = '';
  late final _profileRepo = ref.read(adminProfileRepositoryAdapterProvider);

  String _badgeText(int unreadCount) => unreadCount > 9 ? '9+' : '$unreadCount';

  void _refreshBaseUrl() {
    _baseUrl = ref.read(apiClientProvider).dio.options.baseUrl.trim();
  }

  Future<void> _loadAccessToken() async {
    final token = await ref.read(sessionServiceProvider).readAccessToken();
    if (!mounted) return;
    updateLocalUiState(this, () => _accessToken = token?.trim() ?? '');
  }

  void _reloadUnreadCount() {
    ref
        .read(appBarNotificationBadgeControllerProvider(AppRoutePaths.adminNotifications))
        .reload();
  }

  void _startBadgeRefresh() {
    _badgeRefreshTimer?.cancel();
    _badgeRefreshTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (!mounted) return;
      _reloadUnreadCount();
    });
  }

  Future<void> _loadProfile() async {
    _profileToken?.cancel('Reload profile');
    final token = AppCancellationHandle();
    _profileToken = token;

    if (!mounted) return;
    updateLocalUiState(this, () => _loadingProfile = true);

    try {
      _refreshBaseUrl();
      final res = await _profileRepo.getMyProfile(cancelToken: token);
      if (!mounted) return;

      res.when(
        success: (profile) {
          if (!mounted) return;
          updateLocalUiState(this, () {
            _profile = profile;
            _loadingProfile = false;
          });
        },
        failure: (error) {
          if (LegacyErrorPresenter.isApiFailure(error) &&
              (LegacyErrorPresenter.statusCode(error) == 401 || LegacyErrorPresenter.statusCode(error) == 403)) {
            if (!mounted) return;
            updateLocalUiState(this, () {
              _profile = null;
              _loadingProfile = false;
            });
            return;
          }
          if (!mounted) return;
          updateLocalUiState(this, () {
            _profile = null;
            _loadingProfile = false;
          });
        },
      );
    } catch (_) {
      if (!mounted) return;
      updateLocalUiState(this, () {
        _profile = null;
        _loadingProfile = false;
      });
    }
  }

  String _initials(String name, String username) {
    final source = name.isNotEmpty ? name : username;
    final clean = source.replaceAll('@', ' ').trim();
    if (clean.isEmpty) return '--';
    final parts = clean
        .split(RegExp(r'\s+'))
        .where((e) => e.isNotEmpty)
        .toList();
    if (parts.isEmpty) return '--';
    return parts.take(2).map((e) => e[0]).join().toUpperCase();
  }

  String _buildAbsoluteUrl(String value) {
    final trimmed = value.trim();
    if (trimmed.isEmpty) return '';
    final parsed = Uri.tryParse(trimmed);
    if (parsed != null && parsed.hasScheme && parsed.hasAuthority) {
      return parsed.toString();
    }
    final base = _baseUrl.trim();
    if (base.isEmpty) return trimmed;
    final normalizedBase = base.endsWith('/') ? base.substring(0, base.length - 1) : base;
    final normalizedPath = trimmed.startsWith('/') ? trimmed : '/$trimmed';
    return '$normalizedBase$normalizedPath';
  }

  String _extractProfileImageUrl(AdminProfile? profile) {
    if (profile == null) return '';
    final sources = <Map<String, dynamic>>[profile.raw, profile.data];
    final level1 = profile.raw['data'];
    if (level1 is Map) {
      final level1Map = Map<String, dynamic>.from(level1.cast());
      sources.add(level1Map);
      final level2 = level1Map['data'];
      if (level2 is Map) {
        sources.add(Map<String, dynamic>.from(level2.cast()));
      }
    }

    const keys = [
      'profileUrl',
      'profileurl',
      'profile_url',
      'avatarUrl',
      'avatar_url',
      'avatar',
      'photoUrl',
      'photo_url',
      'imageUrl',
      'image_url',
      'profileImage',
      'profile_image',
    ];

    for (final map in sources) {
      for (final key in keys) {
        final value = map[key];
        if (value == null) continue;
        final text = value.toString().trim();
        if (text.isEmpty) continue;
        return _buildAbsoluteUrl(text);
      }
    }

    return '';
  }

  Future<void> _confirmLogout() async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (_) => const _LogoutConfirmDialog(),
    );
    if (shouldLogout != true) return;
    final sessionService = ref.read(sessionServiceProvider);
    await sessionService.logout();
    if (!mounted) return;
    final restoredToken = await sessionService.readAccessToken();
    if (!mounted) return;
    if (restoredToken != null && restoredToken.trim().isNotEmpty) {
      if (!mounted) return;
      context.go(AppRoutePaths.superadminHome);
      return;
    }
    if (!mounted) return;
    context.go(AppRoutePaths.login);
  }

  Future<void> _showProfileMenu({
    required BuildContext anchorContext,
    required String displayName,
    required String roleLabel,
    required String imageUrl,
    required String initials,
  }) async {
    final box = anchorContext.findRenderObject() as RenderBox?;
    final overlay =
        Overlay.of(context).context.findRenderObject() as RenderBox?;
    if (box == null || overlay == null) return;
    final media = MediaQuery.of(context);
    final topOffset = media.padding.top + AppUtils.appBarHeightCustom + 12 + 8;
    final rightEdge = overlay.size.width - 12;
    final menuWidth = 200.0;
    final position = RelativeRect.fromLTRB(
      rightEdge - menuWidth,
      topOffset,
      12,
      overlay.size.height - topOffset,
    );

    final selected = await showMenu<String>(
      context: context,
      position: position,
      color: Theme.of(context).colorScheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      items: [
        PopupMenuItem<String>(
          enabled: false,
          child: SizedBox(
            width: menuWidth,
            child: Row(
              children: [
                _ProfileAvatar(
                  radius: 22,
                  fontSize: 14,
                  colorScheme: Theme.of(context).colorScheme,
                  imageUrl: imageUrl,
                  initials: initials,
                  loading: _loadingProfile,
                  authToken: _accessToken,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        displayName.isNotEmpty ? displayName : '—',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppFonts.roboto(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        roleLabel,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppFonts.roboto(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: Theme.of(context)
                              .colorScheme
                              .onSurface
                              .withOpacity(0.6),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        PopupMenuDivider(
          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.2),
        ),
        PopupMenuItem<String>(
          value: 'profile',
          height: 36,
          child: Row(
            children: const [
              Expanded(child: Text('Profile')),
              Icon(Icons.chevron_right, size: 18),
            ],
          ),
        ),
        PopupMenuDivider(
          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.2),
        ),
        PopupMenuItem<String>(
          value: 'logout',
          height: 36,
          child: Row(
            children: const [
              Expanded(
                child: Text(
                  'Logout',
                  style: TextStyle(color: OpenVtsColors.danger),
                ),
              ),
              Icon(Icons.logout, size: 18, color: OpenVtsColors.danger),
            ],
          ),
        ),
      ],
    );

    if (!mounted || selected == null) return;
    if (selected == 'profile') {
      context.push(AppRoutePaths.adminSettings);
    } else if (selected == 'logout') {
      await _confirmLogout();
    }
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _loadAccessToken();
      _reloadUnreadCount();
      _startBadgeRefresh();
      _loadProfile();
    });
  }

  @override
  void dispose() {
    _badgeRefreshTimer?.cancel();
    _profileToken?.cancel('HomeScreen disposed');
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final screenWidth = MediaQuery.of(context).size.width;
    final isDark = theme.brightness == Brightness.dark;

    final double hp = AdaptiveUtils.getHorizontalPadding(screenWidth);
    final double iconSize = AdaptiveUtils.getIconSize(screenWidth);
    final double buttonSize = AdaptiveUtils.getButtonSize(screenWidth);
    final double subtitleFontSize = AdaptiveUtils.getSubtitleFontSize(
      screenWidth,
    );
    final double bellNotificationFontSize =
        AdaptiveUtils.getBellNotificationFontSize(screenWidth);

    final double gridGap = hp * 1.3;
    final double tileSize = (screenWidth - (hp * 2) - (gridGap * 2)) / 3;
    final double labelFontSize =
        AdaptiveUtils.getTitleFontSize(screenWidth) + 1;

    final String logoAsset = AppLogo.assetFor(context);

    const footerText = '© 2026 Open VTS All rights reserved.';
    final unreadCount = ref.watch(
      appBarUnreadCountProvider(AppRoutePaths.adminNotifications),
    ).maybeWhen(
      data: (count) => count,
      orElse: () => 0,
    );
    final profileImageUrl = _extractProfileImageUrl(_profile);
    final roleLabel = (_profile?.roleName.trim().isNotEmpty ?? false)
      ? _profile!.roleName.trim()
      : 'Admin';

    final List<_HomeShortcut> shortcuts = [
      _HomeShortcut(
        label: 'Dashboard',
        icon: Symbols.finance,
        route: AppRoutePaths.adminDashboard,
      ),
      _HomeShortcut(
        label: 'Users',
        icon: Symbols.group,
        route: AppRoutePaths.adminUsers,
      ),
      _HomeShortcut(
        label: 'Vehicles',
        icon: Symbols.sync_alt,
        route: AppRoutePaths.adminVehicles,
      ),
      _HomeShortcut(
        label: 'Drivers',
        icon: Symbols.badge,
        route: AppRoutePaths.adminDrivers,
      ),
      _HomeShortcut(
        label: 'Team',
        icon: Symbols.groups,
        route: AppRoutePaths.adminTeams,
      ),
      _HomeShortcut(
        label: 'Inventory',
        icon: Symbols.inventory_2,
        route: AppRoutePaths.adminInventory,
      ),
      _HomeShortcut(
        label: 'Maps',
        icon: Symbols.map,
        route: AppRoutePaths.adminMap,
      ),
      _HomeShortcut(
        label: 'Transactions',
        icon: Symbols.receipt_long,
        route: AppRoutePaths.adminTransactions,
      ),
      _HomeShortcut(
        label: 'Payments',
        icon: Symbols.credit_card,
        route: AppRoutePaths.adminPayments,
      ),
      _HomeShortcut(
        label: 'Support',
        icon: Symbols.help,
        route: AppRoutePaths.adminSupport,
      ),
      _HomeShortcut(
        label: 'Calendar',
        icon: Symbols.date_range,
        route: AppRoutePaths.adminCalendar,
      ),
      _HomeShortcut(
        label: 'Logs',
        icon: Symbols.list_alt,
        route: AppRoutePaths.adminLogs,
      ),
      _HomeShortcut(
        label: 'Plans',
        icon: Symbols.widgets,
        route: AppRoutePaths.adminPlans,
      ),
      // _HomeShortcut(
      //   label: 'Roles',
      //   icon: Symbols.admin_panel_settings,
      //   route: AppRoutePaths.adminRoles,
      // ),
      _HomeShortcut(
        label: 'Settings',
        icon: Symbols.brightness_5,
        route: AppRoutePaths.adminSettings,
      ),
    ];

    return Scaffold(
      backgroundColor: isDark
          ? OpenVtsColors.panelDark
          : OpenVtsColors.panelLight,
      appBar: TopBar(
        title: 'Administrators',
        onClose: () => Navigator.of(context).pop(),
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: _HomeHeader(
              logoAsset: logoAsset,
              hp: hp,
            ),
          ),
          SliverPadding(
            padding: EdgeInsets.fromLTRB(hp, 24, hp, 48),
            sliver: SliverGrid(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: gridGap,
                crossAxisSpacing: gridGap,
                childAspectRatio: tileSize / (tileSize + 32),
              ),
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final item = shortcuts[index];
                  return _HomeShortcutTile(
                    item: item,
                    onTap: () => context.push(item.route),
                    tileSize: tileSize,
                    labelFontSize: labelFontSize,
                    colorScheme: cs,
                  );
                },
                childCount: shortcuts.length,
              ),
            ),
          ),
          SliverFillRemaining(
            hasScrollBody: false,
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 24),
                child: Text(
                  footerText,
                  style: AppFonts.roboto(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: cs.onSurface.withOpacity(0.4),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HomeHeader extends StatelessWidget {
  final String logoAsset;
  final double hp;

  const _HomeHeader({
    required this.logoAsset,
    required this.hp,
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    return Padding(
      padding: EdgeInsets.fromLTRB(hp, 28, hp, 8),
      child: Center(
        child: Image.asset(
          logoAsset,
          width: (screenWidth * 0.45).clamp(140.0, 200.0),
          fit: BoxFit.contain,
        ),
      ),
    );
  }
}

class _HeaderIconButton extends StatelessWidget {
  final IconData icon;
  final double size;
  final double iconSize;
  final ColorScheme colorScheme;
  final bool showBadge;
  final String badgeText;
  final double badgeFontSize;
  final VoidCallback onTap;

  const _HeaderIconButton({
    required this.icon,
    required this.size,
    required this.iconSize,
    required this.colorScheme,
    required this.showBadge,
    required this.badgeText,
    required this.badgeFontSize,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(size / 2),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            height: size,
            width: size,
            decoration: BoxDecoration(
              color: colorScheme.surface,
              shape: BoxShape.circle,
              border: Border.all(
                color: colorScheme.onSurface.withOpacity(0.2),
                width: 1,
              ),
            ),
            alignment: Alignment.center,
            child: Icon(icon, size: iconSize, color: colorScheme.primary),
          ),
          if (showBadge)
            Positioned(
              top: -size * 0.15,
              right: -size * 0.15,
              child: Container(
                padding: const EdgeInsets.all(4),
                constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                decoration: BoxDecoration(
                  color: colorScheme.primary,
                  shape: BoxShape.circle,
                ),
                alignment: Alignment.center,
                child: Text(
                  badgeText,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: colorScheme.onPrimary,
                    fontSize: badgeFontSize,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _HomeShortcut {
  final String label;
  final IconData icon;
  final String route;

  const _HomeShortcut({
    required this.label,
    required this.icon,
    required this.route,
  });
}

class _HomeShortcutTile extends StatelessWidget {
  final _HomeShortcut item;
  final double tileSize;
  final double labelFontSize;
  final ColorScheme colorScheme;
  final VoidCallback onTap;

  const _HomeShortcutTile({
    required this.item,
    required this.tileSize,
    required this.labelFontSize,
    required this.colorScheme,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final double screenWidth = MediaQuery.of(context).size.width;
    final cs = Theme.of(context).colorScheme;
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    final Color neutralColor = cs.onSurface.withOpacity(isDark ? 0.86 : 0.75);
    final double iconContainerSize = tileSize * 0.6;
    final double iconSize = AdaptiveUtils.isVerySmallScreen(screenWidth)
        ? 20
        : AdaptiveUtils.isSmallScreen(screenWidth)
        ? 22
        : 24;
    return InkWell(
      onTap: onTap,
      borderRadius: AppUtils.borderRadiusMedium,
      splashColor: cs.surfaceContainerHighest.withOpacity(0.4),
      highlightColor: cs.surfaceContainerHighest.withOpacity(0.4),
      hoverColor: cs.surfaceContainerHighest.withOpacity(0.4),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            height: iconContainerSize,
            width: iconContainerSize,
            decoration: BoxDecoration(
              color: cs.surface,
              borderRadius: const BorderRadius.all(Radius.circular(24)),
              border: Border.all(
                color: cs.onSurface.withOpacity(0.2),
                width: 1,
              ),
            ),
            alignment: Alignment.center,
            child: Icon(item.icon, size: iconSize, color: cs.primary),
          ),
          SizedBox(height: AppUtils.spacingSmall),
          Text(
            item.label,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: AppFonts.roboto(
              fontSize: labelFontSize,
              fontWeight: FontWeight.w600,
              color: neutralColor,
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileAvatar extends StatelessWidget {
  final double radius;
  final double fontSize;
  final ColorScheme colorScheme;
  final String imageUrl;
  final String initials;
  final bool loading;
  final String authToken;

  const _ProfileAvatar({
    required this.radius,
    required this.fontSize,
    required this.colorScheme,
    required this.imageUrl,
    required this.initials,
    required this.loading,
    required this.authToken,
  });

  @override
  Widget build(BuildContext context) {
    if (imageUrl.isNotEmpty) {
      final double size = radius * 2;
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.light
              ? colorScheme.surface
              : colorScheme.surfaceContainerHighest,
          shape: BoxShape.circle,
        ),
        child: ClipOval(
          child: CachedNetworkImage(
            imageUrl: imageUrl,
            width: size,
            height: size,
            fit: BoxFit.cover,
            httpHeaders: authToken.isNotEmpty
                ? {'Authorization': 'Bearer $authToken'}
                : null,
            placeholder: (_, __) => _InitialsAvatar(
              radius: radius,
              fontSize: fontSize,
              colorScheme: colorScheme,
              initials: loading ? '--' : initials,
            ),
            errorWidget: (_, __, ___) => _InitialsAvatar(
              radius: radius,
              fontSize: fontSize,
              colorScheme: colorScheme,
              initials: loading ? '--' : initials,
            ),
          ),
        ),
      );
    }

    return _InitialsAvatar(
      radius: radius,
      fontSize: fontSize,
      colorScheme: colorScheme,
      initials: loading ? '--' : initials,
    );
  }
}

class _InitialsAvatar extends StatelessWidget {
  final double radius;
  final double fontSize;
  final ColorScheme colorScheme;
  final String initials;

  const _InitialsAvatar({
    required this.radius,
    required this.fontSize,
    required this.colorScheme,
    required this.initials,
  });

  @override
  Widget build(BuildContext context) {
    final double size = radius * 2;
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: Theme.of(context).brightness == Brightness.light
            ? colorScheme.surface
            : colorScheme.surfaceContainerHighest,
        shape: BoxShape.circle,
        border: Border.all(
          color: colorScheme.onSurface.withOpacity(0.2),
          width: 1,
        ),
      ),
      alignment: Alignment.center,
      child: Text(
        initials,
        style: AppFonts.roboto(
          fontSize: fontSize,
          fontWeight: FontWeight.w700,
          color: colorScheme.onSurface,
        ),
      ),
    );
  }
}

class _LogoutConfirmDialog extends StatelessWidget {
  const _LogoutConfirmDialog();

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;

    return Dialog(
      backgroundColor: colorScheme.surface,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: colorScheme.primary.withOpacity(0.12),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    CupertinoIcons.square_arrow_right,
                    color: colorScheme.primary,
                    size: 20,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Log out?',
                    style: AppFonts.roboto(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: colorScheme.onSurface,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              'Your current session will end. You will need to log in again to continue.',
              style: AppFonts.roboto(
                fontSize: 14,
                color: colorScheme.onSurface.withOpacity(0.7),
              ),
            ),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(46),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: Text(
                      'Cancel',
                      style: AppFonts.roboto(fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.of(context).pop(true),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size.fromHeight(46),
                      backgroundColor: colorScheme.primary,
                      foregroundColor: colorScheme.onPrimary,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: Text(
                      'Log out',
                      style: AppFonts.roboto(fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
